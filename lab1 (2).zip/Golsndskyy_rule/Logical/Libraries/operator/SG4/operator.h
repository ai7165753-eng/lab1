/* This library does not contain C code */

